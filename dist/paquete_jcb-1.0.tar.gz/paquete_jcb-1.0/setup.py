from setuptools import setup

setup(
    name="paquete_jcb",
    version="1.0",
    description="Paquete para carga de Usuario Cliente y Gestión de Compras",
    author="JAC@R2000 - Javier Caramella Boubet de la Comisión 51325",

    packages=["paquete_entregable"],
)