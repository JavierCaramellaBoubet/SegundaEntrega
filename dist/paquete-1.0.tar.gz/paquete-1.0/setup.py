from setuptools import setup

setup(
    name="paquete",
    version="1.0",
    description="Paquete para carga de Usuario Cliente y Gestión de Compras",
    author="JAC@R2000 - Javier Caramella Boubet",

    packages=["paquete"],
)